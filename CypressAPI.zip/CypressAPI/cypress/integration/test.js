//defining global varaible
let rowsLength;
var emailID = Math.random().toString(36).substring(2, 15)+"kishor@domain.com" 
var password = "testPassword"
var id
  
describe('Get Products', () => {
    context('GET /produtos', () => {
      it('Getting the details of the products', () => {
        cy.request({
            method: 'GET',
            url: '/produtos'
        })
        .should((response) => {
           // cy.log(JSON.stringify(response.body))
            // assert response code
            expect(response.status).to.eq(200)
            //assert response text from the list
         //   expect(response.body.produtos[0].nome).to.eq('Lennie Dickinson')              
              
        });
      });
    });
  });

  describe ('Register users', () =>{
      context('Post /user', () => {
          before(() =>{
              cy.task('readXlsx', { file: 'cypress/fixtures/testData.xlsx', sheet: "Sheet1" }).then((rows) => {
                  rowsLength = rows.length;
                  cy.writeFile("cypress/fixtures/testData.json", {rows})
              })
          })
          it ('Registering new users', () =>{
              cy.fixture('testData').then((data) => {
                  for (let i = 0; i < rowsLength; i++) {
                      cy.request ({
                          method: 'POST',
                          url: '/usuarios',
                          failOnStatusCode: false,
                          body: {
                              nome: data.rows[i].name,
                              email: emailID,
                              password: password,
                              administrador: "true"
                          }
                      })
                      .should((response) =>{
                          cy.log(JSON.stringify(response.body))
                          expect(response.status).to.eq(data.rows[i].responseCode)
                          expect(response.body.message).eq(data.rows[i].responseMessage)  
                          //id = (response.body._id)
                      })
                  }
              })

              cy.request ({
                method: 'POST',
                url: '/usuarios',
                body: {
                  nome: "Whiskey Blues",
                  email: "test"+emailID,
                  password: password,
                  administrador: "true"
                }
              })
              .should((response) => {
                expect(response.status).to.eq(201)
                id = (response.body._id)
              })
          })
      })
  })
  

  describe('Login user', () => {
    context('User should be logged in successfully after registration', () => {
      it('Login user', () => {
        cy.request({
            method: 'POST',
            url: '/login',
            body: {
              email: emailID,
              password: password
            }
        })
        .should((response) => {
            cy.log(JSON.stringify(response.body))
            // assert response code
           expect(response.status).to.eq(200)
            //assert response text from the list
            expect(response.body.message).eq('Login realizado com sucesso')             
        });
      });
    });
  });

  describe('Get user', () => {
    context('Getting user details', () => {
      it('Get user', () => {
        cy.request({
            method: 'GET',
            url: `usuarios/${id}`
        })
        .should((response) => {
            cy.log(JSON.stringify(response.body))
            // assert response code
           expect(response.status).to.eq(200)            
        });
      });
    });
  });
  describe('Delete user', () => {
    context('User should be deleted successfully', () => {
      it('Delete user', () => {
        cy.request({
            method: 'DELETE',
            url: `/usuarios/${id}`
        })
        .should((response) => {
            cy.log(JSON.stringify(response.body))
            // assert response code
           expect(response.status).to.eq(200)
            //assert response text from the list
            expect(response.body.message).eq('Registro excluído com sucesso')             
        });
      });
    });
  });